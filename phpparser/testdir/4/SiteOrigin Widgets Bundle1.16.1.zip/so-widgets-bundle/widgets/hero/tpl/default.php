<?php

$this->render_template($instance['controls'], $instance['frames']);