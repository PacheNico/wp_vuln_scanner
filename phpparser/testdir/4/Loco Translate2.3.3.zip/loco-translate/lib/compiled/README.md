# Compiled libraries

These files are built from the Loco core. Do not edit!

They've been converted down for PHP 5.2 compatibility in WordPress.
