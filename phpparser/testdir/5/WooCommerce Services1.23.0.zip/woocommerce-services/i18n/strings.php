<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$i18nStrings = array(
__( "Dismiss", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Required", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Optional", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "More", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "All services selected", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "%(numSelected)d service selected", "%(numSelected)d services selected", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Expand Services", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Service", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Price adjustment", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Increase the rates calculated by the carrier to account for packaging and handling costs. You can also add a negative amount to save your customers money.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Saved Packages", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add and edit saved packages using the {{a}}Packaging Manager{{/a}}.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "You have unsaved changes.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Your changes have been saved.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "There was a problem with one or more entries. Please fix the errors below and try saving again.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Save changes", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Saving…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Save Settings", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "We have slightly modified the address entered. If correct, please use the suggested address to ensure accurate delivery.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Address entered", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Suggested address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Use selected address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Edit address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "We were unable to automatically verify the address — %(error)s.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "We were unable to automatically verify the address.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Address entered", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Automatic verification failed for this address. It may still be a valid address — use the tools below to manually verify.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Verify with USPS", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "View on Google Maps", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Edit address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Use address as entered", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Name", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Company", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Phone", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(message)s. Please modify the address and try again.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "City", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "State", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Select one…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "State", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Postal code", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Country", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Verify address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Use address as entered", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Expand", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Validating address…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Invalid address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "You've edited the address, please revalidate it for accurate rates", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Packages to be Shipped", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Move", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
/* translators: Length placeholder for dimensions input */
__( "L", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
/* translators: Width placeholder for dimensions input */
__( "W", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
/* translators: Height placeholder for dimensions input */
__( "H", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Invalid value.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "This field is required.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Type of package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Box", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Envelope", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Package name", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Unique package name", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "This field must be unique", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Dimensions (L x W x H)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Weight of empty package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "0.0", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Untitled", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "All packages selected", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "%(selectedCount)d package selected", "%(selectedCount)d packages selected", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Expand Services", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Your shipping packages have been saved.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Unable to save your shipping packages. Please try again.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "Add package", "Add packages", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Done", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Cancel", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "{{icon/}} Delete this package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Individually Shipped Item", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Item Dimensions", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Package details", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Select a package type", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Please select a package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add items", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Items to fulfill", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Weight", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "QTY", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "There are no items in this package.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Total Weight (with package)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "0", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "{{itemLink/}} is currently saved for a later shipment.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "{{itemLink/}} is currently shipped in its original packaging.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "{{itemLink/}} is currently in {{pckg/}}.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Cancel", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Submit", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Move item", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Where would you like to move it?", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add to a New Package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Ship in original packaging", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(item)s from {{pckg/}}", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Close", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add item", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Which items would you like to add to {{pckg/}}?", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Packaging", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "No packages selected", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "1 item in 1 package: %(weight)s %(unit)s total", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(itemsCount)d items in 1 package: %(weight)s %(unit)s total", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(itemsCount)d items in %(packageCount)d packages: %(weight)s %(unit)s total", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Use these packages", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "HS Tariff number", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "more info", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Origin country", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Country where the product was manufactured or assembled", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Description", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Weight (%s per unit)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Value ($ per unit)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Description", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Optional", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Weight (per unit)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Value (per unit)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Return to sender if package is unable to be delivered", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Contents type", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Merchandise", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Documents", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Gift", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Sample", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Other…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Details", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Restriction type", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "None", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Quarantine", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Sanitary / Phytosanitary inspection", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Other…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Details", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "ITN", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "more info", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Customs information incomplete", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Customs information valid", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Customs", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Save customs form", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "The service and rate chosen by the customer at checkout is not available. Please choose another.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Choose rate: %(pckg)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Unsaved changes made to packages", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "No rates found", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(serviceName)s: %(rate)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Total rate: %(total)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Shipping rates", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Customer paid a {{shippingMethod/}} of {{shippingCost/}} for shipping", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Your customer selected {{shippingMethod/}}", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "WooCommerce Services gives you access to USPS Commercial Pricing, which is discounted over Retail rates.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "You save %s with WooCommerce Services", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Package %(index)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Total", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Shipping summary", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Shipping from", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Edit", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "shipping label ready", "shipping labels ready", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Print", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Purchasing…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "Buy shipping label", "Buy shipping labels", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Choose credit card", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "To print this shipping label, {{a}}choose a credit card to add to your account{{/a}}.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add credit card", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "To print this shipping label, {{a}}add a credit card to your account{{/a}}.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Paper size", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Notify the customer with shipment details", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Mark this order as complete and notify the customer", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "Create shipping label", "Create shipping labels", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Origin address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Destination address", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Toggle menu", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Cancel", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Refund label (-%(amount)s)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Request a refund", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "You can request a refund for a shipping label that has not been used to ship a package. It will take at least 14 days to process.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Purchase date", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Amount eligible for refund", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Cancel", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Print", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Reprint shipping label", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "If there was a printing error when you purchased the label, you can print it again.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "NOTE: If you already used the label in a package, printing and using it again is a violation of our terms of service and may result in criminal charges.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Paper size", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Close", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Label #%(labelIndex)s details", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Receipt", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Service", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Items", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "N/A", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Labels older than 30 days cannot be refunded.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Request refund", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Request refund", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Label images older than 180 days are deleted by our technology partners for general security and data privacy concerns.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Reprint", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Reprint", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "View details", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Schedule a pickup", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(service)s label (#%(labelIndex)d)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Tracking #: {{trackingLink/}}", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(service)s label (#%(labelIndex)d)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Purchasing…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Internal note", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Note sent to customer", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(service)s label (#%(labelNum)d) refund requested (%(amount)s)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(service)s label (#%(labelNum)d) refunded (%(amount)s)", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(service)s label (#%(labelNum)d) refund rejected", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Refund", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Refunded %(amount)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Note", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "%(count)s event", "%(count)s events", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Show notes from %(date)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "No activity yet", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Which package would you like to track?", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Create shipping label", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "Track Package", "Track Packages", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Create new label", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "Track Package", "Track Packages", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Create shipping label", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Connection error: unable to create label at this time", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "%(itemCount)d item was fulfilled on {{span}}%(createdDate)s{{/span}}", "%(itemCount)d items were fulfilled on {{span}}%(createdDate)s{{/span}}", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "%(itemCount)d item is ready to be fulfilled", "%(itemCount)d items are ready to be fulfilled", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "No tracking information available at this time", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
/* translators: Name for WeChat Pay - https://pay.weixin.qq.com/ */
__( "WeChat Pay", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "American Express", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Discover", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "MasterCard", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "VISA", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "PayPal", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "%(card)s ****%(digits)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_x( "Expires %(date)s", "date is of the form MM/YY", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Only the site owner can manage shipping label payment methods. Please contact %(ownerName)s (%(ownerLogin)s) to manage payment methods.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Retry", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Only the site owner can change these settings. Please contact %(ownerName)s (%(ownerLogin)s) to change the shipping label settings.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Credit cards are retrieved from the following WordPress.com account: %(wpcomLogin)s <%(wpcomEmail)s>", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "We'll charge the credit card on your account (%(card)s) to pay for the labels you print", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "To purchase shipping labels, add a credit card.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Choose a different card", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "To purchase shipping labels, choose a credit card you have on file or add a new card.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add another credit card", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "To purchase shipping labels, add a credit card.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add a credit card", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Email Receipts", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Email the label purchase receipts to %(ownerName)s (%(ownerLogin)s) at %(ownerEmail)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Paper size", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Payment", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Unable to get your settings. Please refresh the page to try again.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Shipping Labels", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Print shipping labels yourself and save a trip to the post office.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Name", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Dimensions", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Edit", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Remove", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Packaging", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add boxes, envelopes, and other packages you use most frequently.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Add package", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Return to Order #%(orderId)s", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Your shipping settings have been saved.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Unable to save your shipping settings. Please try again.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "A payment method is required to print shipping labels.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Save changes", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_x( "Health", "This section displays the overall health of WooCommerce Services and the things it depends on", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Last updated %s. {{a}}Refresh{{/a}}", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Refresh", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "WooCommerce", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Jetpack", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "WooCommerce Services Data", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Log tail copied to clipboard", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
_n( "Last %s entry. {{a}}Show full log{{/a}}", "Last %s entries. {{a}}Show full log{{/a}}", 1, "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Copy for support", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Request was made %s - check logs below or {{a}}edit service settings{{/a}}", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Edit service settings", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Services", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "No services configured. {{a}}Add a shipping service{{/a}}", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Debug", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Debug", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Display troubleshooting information on the Cart and Checkout pages.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Enabled", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Disabled", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Logging", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Write diagnostic messages to log files. Helpful when contacting support.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Enabled", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Disabled", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Shipping Log", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Taxes Log", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Other Log", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Support", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Need help?", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Our team is here for you. View our {{docsA}}support docs{{/docsA}} or {{ticketA}}open a support ticket{{/ticketA}}.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Activated", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Check email to activate account", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Disconnecting", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Disconnect", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Stripe account", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "Account disconnected. Reloading page…", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
__( "You’ve got WooCommerce Services installed. If you’d like, we can automatically copy keys from your Stripe account for you. {{a}}Click here{{/a}} to connect your Stripe account using WooCommerce Services.", "woocommerce-services" ), // dist/woocommerce-services-1.23.0.js:107
);
/* THIS IS THE END OF THE GENERATED FILE */