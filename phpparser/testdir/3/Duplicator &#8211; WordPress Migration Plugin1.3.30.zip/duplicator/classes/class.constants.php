<?php
defined("ABSPATH") || exit;
class DUP_Constants
{
    const ZIP_STRING_LIMIT = 70000;   // Cutoff for using ZipArchive addtostring vs addfile
}
