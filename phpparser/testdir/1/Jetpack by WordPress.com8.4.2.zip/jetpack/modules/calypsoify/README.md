# calypsoify
WordPress plugin for redesigning WP-Admin plugin screens to match Calypso.

![](https://cldup.com/awmrHOWz7t.png)
