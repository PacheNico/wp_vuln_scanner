<?php
/**
 * Deprecated since 7.7
 */
_deprecated_file( basename( __FILE__ ), 'jetpack-7.7' );
